<?php
include 'koneksi.php';

echo "
<style> 
    table {
        border-collapse: collapse;
        width: 100%;
    }
    th, td {
        padding: 8px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }
    tr:hover {
        background-color: #f5f5f5;
    }
    .button-container {
        margin-top: 10px;
    }
    .button-container a {
        display: inline-block;
        margin-right: 10px;
        padding: 6px 12px;
        background-color: #4CAF50;
        color: white;
        text-decoration: none;
        border-radius: 4px;
    }
    .button-container a:hover {
        background-color: #45a049;
    }
</style>";

if (isset($_POST['search'])) {
    $search = $_POST['search'];
    $sql    = "SELECT * FROM tabel_krs WHERE id LIKE '%$search%'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        echo "<table>
                <tr>
                    <th>ID</th>
                    <th>NIM</th>
                    <th>ID Jadwal</th>
                    <th>Kode Semester</th>
                    <th>Aksi</th>
                </tr>";

        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
                    <td>".$row['id']."</td>
                    <td>".$row['nim']."</td>
                    <td>".$row['id_jadwal']."</td>
                    <td>".$row['kode_semester']."</td>
                    <td>
                        <a href='edit_artikel.php?id=".$row['id']."'>Edit</a>
                        <a href='delete_artikel.php?id=".$row['id']."'>Hapus</a>
                    </td>
                </tr>";
        }

        echo "</table>";
    } else {
        echo "Tidak ada data yang ditemukan.";
    }
}

mysqli_close($conn);
?>

<div class="button-container">
    <a href="tampil_artikel.php">Kembali</a>
</div>
