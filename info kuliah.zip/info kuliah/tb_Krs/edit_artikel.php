<?php
include "koneksi.php";

$id   = $_GET['id'];
$sql  = "SELECT * FROM tabel_krs WHERE id = '$id'";
$result = mysqli_query($conn, $sql);
$row  = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Form KRS</title>
</head>
<body>
    <h1>Form KRS</h1>
    <form name="article" method="POST" action="update_artikel.php">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">

        <table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
                <td width='18%'>NIM</td>
                <td width='2%'>:</td>
                <td width='80%'>
                    <select name="nim">
                        <?php
                        $sqlMahasiswa = "SELECT nim FROM tabel_mahasiswa";
                        $resultMahasiswa = mysqli_query($conn, $sqlMahasiswa);

                        while($row_mahasiswa = mysqli_fetch_assoc($resultMahasiswa)){
                            $selected = ($row_mahasiswa['nim'] == $row['nim']) ? "selected" : "";
                            ?>
                            <option value="<?php echo $row_mahasiswa['nim']; ?>" <?php echo $selected; ?>>
                                <?php echo $row_mahasiswa['nim']; ?>
                            </option>
                            <?php
                        }
                        ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td width='18%'>ID Jadwal</td>
                <td width='2%'>:</td>
                <td width='80%'>
                    <select name="id_jadwal">
                        <?php
                        $sqlJadwal = "SELECT id FROM tabel_jadwal";
                        $resultJadwal = mysqli_query($conn, $sqlJadwal);

                        while($row_jadwal = mysqli_fetch_assoc($resultJadwal)){
                            $selected = ($row_jadwal['id'] == $row['id']) ? "selected" : "";
                            ?>
                            <option value="<?php echo $row_jadwal['id']; ?>" <?php echo $selected; ?>>
                                <?php echo $row_jadwal['id']; ?>
                            </option>
                            <?php
                        }
                        ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td width='18%'>Kode Semester</td>
                <td width='2%'>:</td>
                <td width='80%'>
                    <select name="kode_semester">
                        <?php
                        $sqlSemester = "SELECT kode_semester FROM tabel_semester";
                        $resultSemester = mysqli_query($conn, $sqlSemester);

                        while($row_semester = mysqli_fetch_assoc($resultSemester)){
                            $selected = ($row_semester['kode_semester'] == $row['kode_semester']) ? "selected" : "";
                            ?>
                            <option value="<?php echo $row_semester['kode_semester']; ?>" <?php echo $selected; ?>>
                                <?php echo $row_semester['kode_semester']; ?>
                            </option>
                            <?php
                        }
                        ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>
                    <input type='submit' name='masuk' value='Update' class='tombol'>
                    <input type='reset' name='hapus' value='Cancel' class='tombol'>
                </td>
            </tr>
        </table>
    </form>
</body>
</html>
