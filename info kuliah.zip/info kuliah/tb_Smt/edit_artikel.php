<?php
include 'koneksi.php';

$kode_semester  = $_GET['id'];
$sql  = "SELECT * FROM tabel_semester WHERE kode_semester = '$kode_semester'";
$result = mysqli_query($conn, $sql);
$row  = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Semester</title>
</head>
<body>
    <h1>Form Semester</h1>
    <form name="article" method="POST" action="update_artikel.php">
        <input type="hidden" name="id" value="<?php echo $row['kode_semester']; ?>">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
            <td>Kode Semester</td>
            <td>:</td>
            <td><input type="text" name="kode_semester" size="30" class="masukan" value="<?php echo $row['kode_semester']; ?>"></td>
        </tr>
        <tr>
            <td width="18%">Semester</td>
            <td width="2%">:</td>
            <td width="80%"><input type="text" name="semester" size="30" class="masukan" value="<?php echo $row['semester']; ?>"></td>
        </tr>
        <tr>
            <td width="18%">Status</td>
            <td width="2%">:</td>
            <td width="80%">
                <select name="status">
                    <option value="0">0</option>
                    <option value="1">1</option>
                </select>
            </td>
        </tr>
            <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>
                    <input type="submit" name="masuk" value="Update" class="tombol">
                    <input type="reset" name="hapus" value="Cancel" class="tombol">
                </td>
            </tr>
        </table>
    </form>
</body>
</html>

