<?php
include 'session.php';
$username = $_SESSION['username'];
$userID = $_SESSION['id'];
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Siti Huzaimah</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
    }

    #header {
      background-color: #66b4ef;
      text-align: center;
      padding: 20px;
    }

    #header h1 {
      margin: 0;
    }

    
    #menu {
      background-color: #66b4ef;
      padding: 10px;
    }

    #menu ul {
      list-style-type: none;
      padding: 0;
      margin: 0;
      display: flex;
      justify-content: center;
    }

    #menu ul li {
      margin-right: 20px;
    }

    .menu-container {
      text-align: center;
    }
    .menu-box {
      width: 200px;
      height: 200px;
      background-color: #eaeaea;
      border: 1px solid #ccc;
      text-align: center;
      padding: 20px;
      margin: 10px;
      display: inline-block;
      vertical-align: top;
    }
    .menu-icon {
      font-size: 50px;
      margin-bottom: 10px;
    }
    #content {
      padding: 20px;
    }

    #article_1, #article_2 {
      margin-bottom: 20px;
      padding: 10px;
      background-color: #F5F5F5;
    }

    #sidebar {
      background-color: #F5F5F5;
      padding: 20px;
    }

    #footer {
      background-color: #66b4ef;
      text-align: center;
      padding: 20px;
    }
  </style>
</head>
 
<body>
  <div id="header">
    <h1>Informasi Perkuliahan</h1>
  </div>
 
  <div id="menu">
    <ul>
      <li><a href="#">Home</a></li>
      <li><a href="#">About</a></li>
      <li><a href="#">Contact</a></li>
      <li><a href="logout.php">Logout</a></li>
    </ul>
  </div>
     
<div id="content">
  <div id="article_1">
    <div id="article_header_1">
      <h1 style="text-align: center;">WELCOME</h1>
      <h2 style="text-align: center;">Di sini terdapat beberapa informasi mengenai perkuliahan</h2>
    </div>
    <p style="text-align: center;">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et</p>
  </div>
</div>

<div class="menu-container">
    <div class="menu-box">
      <i class="fas fa-user-graduate menu-icon"></i>
      <h2>Menu Dosen</h2>
      <p>Menampilkan informasi mengenai Dosen</p>
      <a href="tb_Dosen/tampil_artikel.php">Lihat</a>
    </div>
    <div class="menu-box">
      <i class="fas fa-user-graduate menu-icon"></i>
      <h2>Menu Mahasiswa</h2>
      <p>Menampilkan informasi mengenai Mahasiswa</p>
      <a href="tb_Mhs/tampil_artikel.php">Lihat</a>
    </div>
    <div class="menu-box">
      <i class="fas fa-user-graduate menu-icon"></i>
      <h2>Menu MataKuliah</h2>
      <p>Menampilkan informasi mengenai MataKuliah</p>
      <a href="tb_Matkul/tampil_artikel.php">Lihat</a>
    </div>
  </div>
  <div class="menu-container">
    <div class="menu-box">
      <i class="fas fa-user-graduate menu-icon"></i>
      <h2>Menu Semester</h2>
      <p>Menampilkan informasi mengenai Semester</p>
      <a href="tb_Smt/tampil_artikel.php">Lihat</a>
    </div>
    <div class="menu-box">
      <i class="fas fa-user-graduate menu-icon"></i>
      <h2>Menu Jadwal</h2>
      <p>Menampilkan informasi mengenai Jadwal</p>
      <a href="tb_Jadwal/tampil_artikel.php">Lihat</a>
    </div>
    <div class="menu-box">
      <i class="fas fa-user-graduate menu-icon"></i>
      <h2>Menu KRS</h2>
      <p>Menampilkan informasi mengenai KRS</p>
      <a href="tb_Krs/tampil_artikel.php">Lihat</a>
    </div>
  </div>

 
  <div id="footer">
    <p>Copyright Siti Huzaimah 2023</p>
  </div>
</body>
</html>
