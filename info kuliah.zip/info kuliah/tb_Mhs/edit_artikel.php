<?php
include 'koneksi.php';

$nim  = $_GET['id'];
$sql  = "SELECT * FROM tabel_mahasiswa WHERE nim = '$nim'";
$result = mysqli_query($conn, $sql);
$row  = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Mahasiswa</title>
</head>
<body>
    <h1>Form Mahasiswa</h1>
    <form name="article" method="POST" action="update_artikel.php">
        <input type="hidden" name="id" value="<?php echo $row['nim']; ?>">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
            <td>NIM</td>
            <td>:</td>
            <td><input type="text" name="nim" size="30" class="masukan" value="<?php echo $row['nim']; ?>"></td>
        </tr>
        <tr>
            <td width="18%">Nama Mahasiswa</td>
            <td width="2%">:</td>
            <td width="80%"><input type="text" name="nama_mahasiswa" size="30" class="masukan" value="<?php echo $row['nama_mahasiswa']; ?>"></td>
        </tr>
        <tr>
            <td width="18%">Jenis Kelamin</td>
            <td width="2%">:</td>
            <td width="80%">
                <select name="jenis_kelamin">
                    <option value="P">P</option>
                    <option value="L">L</option>
                </select>
            </td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td>:</td>
            <td><textarea name="alamat" rows="8" cols="45"><?php echo $row['alamat']; ?></textarea></td>
        </tr>
        <tr>
            <td width="18%">Jurusan</td>
            <td width="2%">:</td>
            <td width="80%"><input type="text" name="jurusan" size="30" class="masukan" value="<?php echo $row['jurusan']; ?>"></td>
        </tr>
            <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>
                    <input type="submit" name="masuk" value="Update" class="tombol">
                    <input type="reset" name="hapus" value="Cancel" class="tombol">
                </td>
            </tr>
        </table>
    </form>
</body>
</html>

