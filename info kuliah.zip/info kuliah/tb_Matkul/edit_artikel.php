<?php
include 'koneksi.php';

$kode_matakuliah  = $_GET['id'];
$sql  = "SELECT * FROM tabel_matakuliah WHERE kode_matakuliah = '$kode_matakuliah'";
$result = mysqli_query($conn, $sql);
$row  = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Mata Kuliah</title>
</head>
<body>
    <h1>Form Mata Kuliah</h1>
    <form name="article" method="POST" action="update_artikel.php">
        <input type="hidden" name="id" value="<?php echo $row['kode_matakuliah']; ?>">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
            <td>Kode Mata Kuliah</td>
            <td>:</td>
            <td><input type="text" name="kode_matakuliah" size="30" class="masukan" value="<?php echo $row['kode_matakuliah']; ?>"></td>
        </tr>
        <tr>
            <td width="18%">Nama Mata Kuliah</td>
            <td width="2%">:</td>
            <td width="80%"><input type="text" name="nama_matakuliah" size="30" class="masukan" value="<?php echo $row['nama_matakuliah']; ?>"></td>
        </tr>
        <tr>
            <td width="18%">SKS</td>
            <td width="2%">:</td>
            <td width="80%"><input type="text" name="sks" size="30" class="masukan" value="<?php echo $row['sks']; ?>"></td>
        </tr>
            <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>
                    <input type="submit" name="masuk" value="Update" class="tombol">
                    <input type="reset" name="hapus" value="Cancel" class="tombol">
                </td>
            </tr>
        </table>
    </form>
</body>
</html>

