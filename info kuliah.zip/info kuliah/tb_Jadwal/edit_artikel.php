<?php
include "koneksi.php";

$id   = $_GET['id'];
$sql  = "SELECT * FROM tabel_jadwal WHERE id = '$id'";
$result = mysqli_query($conn, $sql);
$row  = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Form Jadwal</title>
</head>
<body>
    <h1>Form Jadwal</h1>
    <form name="article" method="POST" action="update_artikel.php">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">

        <table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
                <td width='18%'>Kode Mata Kuliah</td>
                <td width='2%'>:</td>
                <td width='80%'>
                    <select name="kode_matakuliah">
                        <?php
                        $sqlMatakuliah = "SELECT kode_matakuliah, nama_matakuliah FROM tabel_matakuliah";
                        $resultMatakuliah = mysqli_query($conn, $sqlMatakuliah);

                        while($row_matakuliah = mysqli_fetch_assoc($resultMatakuliah)){
                            $selected = ($row_matakuliah['kode_matakuliah'] == $row['kode_matakuliah']) ? "selected" : "";
                            ?>
                            <option value="<?php echo $row_matakuliah['kode_matakuliah']; ?>" <?php echo $selected; ?>>
                                <?php echo $row_matakuliah['nama_matakuliah']; ?>
                            </option>
                            <?php
                        }
                        ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td width='18%'>Kode Dosen</td>
                <td width='2%'>:</td>
                <td width='80%'>
                    <select name="kode_dosen">
                        <?php
                        $sqlDosen = "SELECT kode_dosen, nama_dosen FROM tabel_dosen";
                        $resultDosen = mysqli_query($conn, $sqlDosen);

                        while($row_dosen = mysqli_fetch_assoc($resultDosen)){
                            $selected = ($row_dosen['kode_dosen'] == $row['kode_dosen']) ? "selected" : "";
                            ?>
                            <option value="<?php echo $row_dosen['kode_dosen']; ?>" <?php echo $selected; ?>>
                                <?php echo $row_dosen['nama_dosen']; ?>
                            </option>
                            <?php
                        }
                        ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td width='18%'>Hari</td>
                <td width='2%'>:</td>
                <td width='80%'><input type="text" name="hari" value="<?php echo $row['hari']; ?>"></td>
            </tr>
            <tr>
                <td width='18%'>Jam</td>
                <td width='2%'>:</td>
                <td width='80%'><input type="text" name="jam" value="<?php echo $row['jam']; ?>"></td>
            </tr>

            <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>
                    <input type='submit' name='masuk' value='Update' class='tombol'>
                    <input type='reset' name='hapus' value='Cancel' class='tombol'>
                </td>
            </tr>
        </table>
    </form>
</body>
</html>
